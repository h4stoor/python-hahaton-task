EMPTY_BOARD = [
    [None for _ in range(15)] for __ in range(15)
]
